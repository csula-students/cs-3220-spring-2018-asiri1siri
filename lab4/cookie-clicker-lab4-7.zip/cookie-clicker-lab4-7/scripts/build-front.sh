#! /bin/bash

cd client && npm run build
