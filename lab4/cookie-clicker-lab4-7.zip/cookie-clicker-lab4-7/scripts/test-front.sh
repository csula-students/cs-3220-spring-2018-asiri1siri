#! /bin/bash

cd client && npm test
