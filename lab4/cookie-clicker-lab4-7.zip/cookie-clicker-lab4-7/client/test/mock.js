export const generator = {
	type: 'autonomous',
	name: 'Grandma',
	description: 'desc',
	rate: 10,
	baseCost: 10,
	quantity: 0,
	unlockValue: 10
};

export const story = {
	name: 'Grandma shows up',
	description: 'desc',
	triggeredAt: 10,
	state: 'hidden'
};
